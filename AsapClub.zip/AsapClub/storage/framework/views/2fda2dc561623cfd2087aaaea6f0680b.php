<!DOCTYPE html>
<html>

<head>
    <style>
        .ss1 {
            background-color: black;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            color:white;
            margin-left: 100px;
            padding-left: 100px;
        }
    </style>

</head>

<body>
    <h1>halo</h1>

    <div class="ss1">halo</div>
</body>

</html><?php /**PATH D:\VisualStudioCode\AsapClub\resources\views/halo.blade.php ENDPATH**/ ?>